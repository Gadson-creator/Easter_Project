# Eastern Hope Ltd — Website

A complete, ready-to-run website for Eastern Hope Ltd, built with plain **HTML5 + CSS3 + vanilla JavaScript**. No build step, no npm, no framework — open `index.html` in a browser and it runs.

---

## 1. What's inside

```
eastern-hope/
├── index.html          → the entire site (one page, anchor-linked sections)
├── style.css            → all styling / design system
├── script.js             → all interactivity: products, quote system, AI assistant, gallery, forms
├── images/                → product illustrations, scene art and favicon (all self-contained SVG — no external image dependency, so nothing ever shows a broken image)
└── README.md            → this file
```

### Sections included
Home / Hero · Trust strip · About (Background, Mission, Vision, Values) · Products (9 items, each with a detail modal) · Industries · Gallery with filtering + lightbox · "Request Steel" natural-language parser · AI Assistant (Eastern Hope AI) · Quote builder (multi-product cart + customer details) · Contact (address, phone, email, form) · Footer with the required **Powered by NeroXiafrica** credit.

---

## 2. How to run it locally

1. Download / copy the `eastern-hope` folder anywhere on your computer.
2. Double-click `index.html` — it opens directly in your browser. That's it.

No server, no terminal, no installation required for local viewing. (A couple of browsers restrict `fetch`/module loading under `file://`, but this site uses none of that, so it works from disk as-is.)

---

## 3. How to publish it (any standard web hosting)

1. Upload the entire `eastern-hope` folder contents (not the folder itself, its *contents*) to your hosting account's public root — usually `public_html`, `www`, or similar — via FTP, cPanel File Manager, or your host's upload tool.
2. Make sure `index.html` sits at the root of that public directory.
3. Visit your domain. Done — no build process, no server-side language required.

This works on virtually any hosting: shared hosting, Netlify, Vercel (static mode), GitHub Pages, cPanel, etc.

---

## 4. Things to configure before going live

Everything below is controlled from **one place** in `script.js`, at the top:

```js
const CONFIG = {
  WHATSAPP_NUMBER: "250788301351",   // confirm this line is WhatsApp-enabled
  CONTACT_EMAIL: "info@easternhopeltd.com",
  COMPANY_NAME: "Eastern Hope Ltd",
  SUBMIT_ENDPOINT: ""                 // see "Forms" below
};
```

### Forms (Quote request & Contact form)
Right now, both forms work with **zero backend** — submitting opens the visitor's email client with a pre-filled message addressed to `info@easternhopeltd.com`. This guarantees the site is never "fake" — every submission really does reach an inbox once sent.

To upgrade to silent, in-page submission (no email client popup), pick one:
- **Formspree** (formspree.io) — create a form, paste the endpoint into `CONFIG.SUBMIT_ENDPOINT`.
- **Netlify Forms** — if hosting on Netlify, add `data-netlify="true"` to the two `<form>` tags and follow Netlify's docs.
- **Your own backend (PHP / Node / Supabase)** — same idea: set `SUBMIT_ENDPOINT` to your API URL.

Then open `script.js`, find `submitLead()`, and uncomment the marked `fetch()` block — it's already written and commented, clearly labelled:
```js
// ---------------- CONNECT REAL BACKEND HERE ----------------
```

### AI Assistant
The **Eastern Hope AI** widget works fully offline using keyword matching and a guided question flow — no AI subscription needed, and it will never break if no API key is present.

To connect a real AI model later (OpenAI, Gemini, Claude, etc.), open `script.js` and find:
```js
// CONNECT REAL AI API HERE
```
Replace the body of `getAiReply()` with a call to **your own backend** (never call an AI provider directly from frontend JavaScript — that would expose your secret API key to every visitor). Your backend holds the key and forwards the request.

### Logo
The site pulls the existing Eastern Hope logo directly from `https://www.easternhopeltd.com/bootstrap/img/banner.png` so it always matches the current brand mark. If you'd rather host it locally, save the file into `images/logo.png` and update the two `<img>` tags in `index.html` that reference the banner URL.

---

## 5. About the product & gallery imagery

Every product card, the hero spec card, and the gallery use custom, purpose-drawn **technical/spec-sheet style SVG graphics** stored in `/images/`. This was a deliberate choice, not a placeholder shortcut:

- **Zero broken images, guaranteed.** Nothing is hot-linked from a third-party stock site whose licensing or link stability can't be verified — every image ships inside the folder and always loads.
- **On-brand.** The line-art / mill-certificate look matches the industrial, technical positioning the brief asked for.
- **Fully replaceable.** Each file is named after the product it represents (`deformed-bars.svg`, `angles.svg`, `hollow-sections.svg`, `tee-angle.svg`, `door-frame.svg`, `bottle-profile.svg`, `flat-bars.svg`, `omega-profile.svg`, `triplex.svg`) plus three general scene images (`scene-warehouse.svg`, `scene-construction.svg`, `scene-industrial.svg`) and `favicon.svg`.

**To swap in real photography:** take (or license) a photo for a product, save it with the **same filename but a raster extension** (e.g. `deformed-bars.jpg`), then in `script.js` update the matching `img:` path inside the `PRODUCTS` array (and `GALLERY` array for gallery photos) from `.svg` to your new filename. No other code changes are needed.

---

## 6. Editing content

- **Products** — edit the `PRODUCTS` array near the top of `script.js` (name, description, specs, size options, keywords used by the AI/NLP parser).
- **Gallery** — edit the `GALLERY` array in `script.js`.
- **Company text** (About, Mission, Vision, Values, Contact details) — edit directly inside `index.html`; it's plain HTML.
- **Colours / fonts / spacing** — all controlled by CSS variables at the top of `style.css` (`:root { --amber: ...; --ink: ...; }` etc.) so the whole palette can be restyled from one place.

---

## 7. No invented business data

In line with the brief, this site does **not** include invented customer counts, sales figures, awards, certifications, branch counts, employee counts, years-of-experience claims, or client names. All company facts (background, mission, vision, values, address, phone numbers, email, product range, sourcing regions) are taken directly from Eastern Hope's existing published website content.

---

## 8. Credit

Powered by **NeroXiafrica** — linked in the site footer to https://neroxiafrica.com/.
